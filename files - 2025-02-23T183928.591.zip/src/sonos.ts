import axios from 'axios';
import { DeskThing } from 'deskthing-server';
import xml2js from 'xml2js';

class SelectedSpeakerStore {
  private static instance: SelectedSpeakerStore;
  public selectedSpeakerIP: string | null = null;

  private constructor() {}

  public static getInstance(): SelectedSpeakerStore {
    if (!SelectedSpeakerStore.instance) {
      SelectedSpeakerStore.instance = new SelectedSpeakerStore();
    }
    return SelectedSpeakerStore.instance;
  }
}

class SonosHandler {
  deviceIP: string | null = null;
  port: number = 1400;
  controlURL = `/MediaRenderer/AVTransport/Control`;
  avTransport = 'AVTransport';
  renderingControl = 'RenderingControl';
  favoritesList: any[] = [];
  deviceUUID: string | null = null;
  lastKnownSongData: any = null;
  pollingInterval: any = null;
  selectedSpeakerUUIDs: string[] | null = null;
  speakersList: { [uuid: string]: { ip: string; zoneName: string } } = {};
  selectedVolumeSpeakers: string[] = [];
  selectedPlaybackSpeakers: string[] = [];
  shuffleState: boolean = false;
  repeatState: 'off' | 'all' | 'one' = 'off';

  async getSpeakerIPByUUID(uuid: string): Promise<string | null> {
    if (this.speakersList && this.speakersList[uuid]) {
      return this.speakersList[uuid].ip;
    }
    this.sendLog(`Speaker IP for UUID ${uuid} not found in cache. Refreshing zone group state...`);
    await this.getZoneGroupState();
    if (this.speakersList[uuid]) {
      this.sendLog(`Found speaker IP after refresh for UUID ${uuid}: ${this.speakersList[uuid].ip}`);
      return this.speakersList[uuid].ip;
    }
    this.sendLog(`Still no speaker IP found for UUID ${uuid} after refresh.`);
    return null;
  }

  async selectVolumeSpeakers(uuids: string[]) {
    this.selectedVolumeSpeakers = uuids;
    this.sendLog(`Selected volume speakers: ${uuids.join(', ')}`);
  }

  async selectPlaybackSpeakers(uuids: string[]) {
    this.selectedPlaybackSpeakers = uuids;
    this.sendLog(`Selected playback speakers: ${uuids.join(', ')}`);
  }

  async selectSpeakers(uuids: string[]) {
    this.selectedSpeakerUUIDs = uuids;
    this.sendLog(`Selected speakers: ${uuids.join(', ')}`);

    if (uuids.length > 0) {
      const firstSpeakerIP = await this.getSpeakerIPByUUID(uuids[0]);
      if (firstSpeakerIP) {
        this.deviceIP = firstSpeakerIP;
        this.sendLog(`Device IP set to: ${this.deviceIP}`);
      } else {
        this.sendError(`IP not found for speaker UUID: ${uuids[0]}`);
      }
    } else {
      this.deviceIP = null;
      this.sendLog('No speakers selected. Device IP unset.');
    }
  }

  async execute(action: string, params: any = {}) {
    if (!this.deviceIP) {
      throw new Error('Sonos device IP is not set. Cannot execute action.');
    }

    params = params || {};
    params.InstanceID = params.InstanceID || 0;

    const url = `http://${this.deviceIP}:${this.port}${this.controlURL}`;
    const soapAction = `"urn:schemas-upnp-org:service:AVTransport:1#${action}"`;
    const xmlParams = Object.keys(params)
      .map((key) => `<${key}>${this.escape(params[key])}</${key}>`)
      .join('');
    const request = `<?xml version="1.0" encoding="utf-8"?>
      <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"
                  s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
          <s:Body>
              <u:${action} xmlns:u="urn:schemas-upnp-org:service:${this.avTransport}:1">
                  ${xmlParams}
              </u:${action}>
          </s:Body>
      </s:Envelope>`;

    try {
      const response = await axios({
        method: 'POST',
        url: url,
        headers: {
          'SOAPAction': soapAction,
          'Content-Type': 'text/xml; charset=utf-8',
        },
        data: request,
      });

      if (response.status !== 200) {
        throw new Error(`Request failed with status ${response.status}: ${response.statusText}`);
      }

      const parser = new xml2js.Parser({ explicitArray: false, ignoreAttrs: true });
      const result = await parser.parseStringPromise(response.data);
      const responseBody = result['s:Envelope']['s:Body'][`u:${action}Response`] || {};
      return responseBody;
    } catch (error: any) {
      this.sendError(`Error executing ${action}: ${error.response ? error.response.data : error.message}`);
      throw error;
    }
  }

  escape(input: string) {
    if (typeof input === 'string') {
      return input.replace(/[<>&'"]/g, (c) =>
        ({
          '<': '&lt;',
          '>': '&gt;',
          '&': '&amp;',
          "'": '&apos;',
          '"': '&quot;',
        }[c])
      );
    }
    return input;
  }

  async addSpeakerToGroup(speakerIP: string, coordinatorIP: string) {
    try {
      if (!coordinatorIP || !speakerIP) {
        throw new Error('Coordinator IP or speaker IP is not provided');
      }

      const coordinatorUUID = await this.getDeviceUUID(coordinatorIP);
      const uri = `x-rincon:${coordinatorUUID}`;
      const originalDeviceIP = this.deviceIP;

      this.deviceIP = speakerIP;
      await this.setAVTransportURI(uri, '');

      this.sendLog(`Speaker ${speakerIP} added to group with coordinator: ${coordinatorUUID}`);

      this.deviceIP = originalDeviceIP;
    } catch (error: any) {
      this.sendError('Error adding speaker to group: ' + error.message);
      console.error('Error adding speaker to group:', error);
    }
  }

  async leaveGroup(speakerIP: string) {
    try {
      const originalDeviceIP = this.deviceIP;

      this.deviceIP = speakerIP;
      const deviceUUID = await this.getDeviceUUID();

      await this.setAVTransportURI(`x-rincon-queue:${deviceUUID}#0`, '');
      this.sendLog(`Speaker ${speakerIP} left the group`);

      this.deviceIP = originalDeviceIP;
    } catch (error: any) {
      this.sendError('Error leaving group: ' + error.message);
      console.error('Error leaving group:', error);
    }
  }

  async getZoneGroupState() {
    const url = `http://${this.deviceIP}:${this.port}/ZoneGroupTopology/Control`;
    const soapAction = `"urn:schemas-upnp-org:service:ZoneGroupTopology:1#GetZoneGroupState"`;
    const request = `<?xml version="1.0" encoding="utf-8"?>
      <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"
                  s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
          <s:Body>
              <u:GetZoneGroupState xmlns:u="urn:schemas-upnp-org:service:ZoneGroupTopology:1"></u:GetZoneGroupState>
          </s:Body>
      </s:Envelope>`;

    try {
      const response = await axios.post(url, request, {
        headers: {
          'SOAPAction': soapAction,
          'Content-Type': 'text/xml; charset=utf-8',
        },
      });

      const parser = new xml2js.Parser({
        explicitArray: false,
        mergeAttrs: true,
        ignoreAttrs: false,
        tagNameProcessors: [xml2js.processors.stripPrefix],
      });
      const result = await parser.parseStringPromise(response.data);

      const zoneGroupState = result['Envelope']['Body']['GetZoneGroupStateResponse']['ZoneGroupState'];

      const xmlParser = new xml2js.Parser({
        explicitArray: false,
        explicitRoot: false,
        mergeAttrs: true,
        ignoreAttrs: false,
        xmlns: false,
        tagNameProcessors: [xml2js.processors.stripPrefix],
      });
      const zoneGroupStateParsed = await xmlParser.parseStringPromise(zoneGroupState);

      const zoneGroups = zoneGroupStateParsed.ZoneGroups?.ZoneGroup;
      if (!zoneGroups) {
        throw new Error('No ZoneGroups found in ZoneGroupState.');
      }

      const groups = Array.isArray(zoneGroups) ? zoneGroups : [zoneGroups];
      const speakersList: { [uuid: string]: { ip: string; zoneName: string } } = {};

      for (const group of groups) {
        const members = Array.isArray(group.ZoneGroupMember)
          ? group.ZoneGroupMember
          : [group.ZoneGroupMember];

        for (const member of members) {
          const uuid = member.UUID;
          const location = member.Location;
          const zoneName = member.ZoneName;
          const ip = this.extractIPAddress(location);

          if (uuid && ip) {
            speakersList[uuid] = { ip, zoneName };
          }
        }
      }

      this.speakersList = speakersList;

      DeskThing.send({
        app: 'sonos-webapp',
        type: 'zoneGroupState',
        payload: zoneGroupState,
      });

      return zoneGroupState;
    } catch (error: any) {
      this.sendError('Error getting zone group state: ' + error.message);
      throw error;
    }
  }

  async joinGroup(coordinatorIP: string, deviceIP: string) {
    try {
      if (!coordinatorIP || !deviceIP) {
        throw new Error('Coordinator IP or device IP is not provided');
      }

      const coordinatorUUID = await this.getDeviceUUID(coordinatorIP);

      const uri = `x-rincon:${coordinatorUUID}`;
      const originalDeviceIP = this.deviceIP;

      this.deviceIP = deviceIP;
      await this.setAVTransportURI(uri, '');

      this.sendLog(`Device ${deviceIP} joined group with coordinator: ${coordinatorUUID}`);

      this.deviceIP = originalDeviceIP;
    } catch (error: any) {
      this.sendError('Error joining group: ' + error.message);
      console.error('Error joining group:', error);
    }