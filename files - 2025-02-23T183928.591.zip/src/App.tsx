import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Player from './pages/Player';
import FavoritesPage from './pages/FavoritesPage';
import VolumeControlPage from './pages/VolumeControlPage';
import './index.css';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Player />} />
        <Route path="/favorites" element={<FavoritesPage />} />
        <Route path="/volume-control" element={<VolumeControlPage />} />
      </Routes>
    </Router>
  );
};

export default App;