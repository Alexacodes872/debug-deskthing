import React, { useEffect, useState } from 'react';
import { DeskThing, SongData } from 'deskthing-client';
import LoadingSpinner from '../components/LoadingSpinner';
import './Player.css';

const Player: React.FC = () => {
  const deskThing = DeskThing.getInstance();
  const [currentSong, setCurrentSong] = useState<SongData | null>(null);
  const [backgroundColor, setBackgroundColor] = useState<string>('');

  useEffect(() => {
    const updateSong = (songData?: SongData) => {
      if (songData) {
        setCurrentSong(songData);
        setBackgroundColor(songData?.color?.rgb || 'rgb(128, 128, 128)');
      }
    };

    const unsubscribe = deskThing.on('music', (songData) => updateSong(songData.payload));

    const fetchInitialData = async () => {
      const song = await deskThing.getMusic();
      if (song) {
        setCurrentSong(song);
      }
    };

    fetchInitialData();

    return () => {
      unsubscribe();
    };
  }, []);

  if (!currentSong || Object.keys(currentSong).length === 0) {
    return (
      <div className="w-screen h-screen">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="player-container" style={{ backgroundColor }}>
      <div className="album-art-container">
        {currentSong.thumbnail && (
          <img src={currentSong.thumbnail} alt={`${currentSong.album} cover`} />
        )}
      </div>
      <div className="track-info-container">
        <h1>{currentSong.track_name}</h1>
        <p>{currentSong.artist}</p>
        <p>{currentSong.album}</p>
      </div>
    </div>
  );
};

export default Player;