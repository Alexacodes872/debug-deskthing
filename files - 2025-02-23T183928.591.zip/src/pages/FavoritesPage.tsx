import React from 'react';
import './FavoritesPage.css';

const FavoritesPage: React.FC = () => {
  return (
    <div className="favorites-page">
      <h1 className="text-4xl mb-6">Favorites Page</h1>
      {/* Add list of favorites here */}
    </div>
  );
};

export default FavoritesPage;