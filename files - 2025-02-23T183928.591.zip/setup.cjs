const { exec } = require('child_process');
const fs = require('fs');

// Function to setup the environment
function setupEnvironment() {
  // Execute setup commands
  exec('npm install', (error, stdout, stderr) => {
    if (error) {
      console.error(`Error installing dependencies: ${error}`);
      return;
    }
    console.log(stdout);
    if (stderr) {
      console.error(`stderr: ${stderr}`);
    }

    // Create .env.local file
    const envContent = `VITE_SONOS_IP=192.168.1.100\n`;
    fs.writeFileSync('.env.local', envContent, 'utf8');
    console.log('.env.local file created.');
  });
}

// Run the setup
setupEnvironment();